document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('note-form');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const title = document.getElementById('title').value;
        const content = document.getElementById('content').value;
        const tags = document.getElementById('tags').value.split(',');
        const backgroundColor = document.getElementById('background-color').value;

        const note = {
            title: title,
            content: content,
            tags: tags,
            backgroundColor: backgroundColor
        };

        fetch('/notes', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(note)
            })
            .then(response => response.json())
            .then(data => {
                displayNotes([data]);
            });
    });

    function displayNotes(notes) {
        const container = document.getElementById('notes-container');
        container.innerHTML = '';
        notes.forEach(note => {
            const noteElement = document.createElement('div');
            noteElement.className = 'note';
            noteElement.style.backgroundColor = note.backgroundColor;
            noteElement.innerHTML = `
                <h2>${note.title}</h2>
                <p>${note.content}</p>
                <p>${note.tags.join(', ')}</p>
            `;
            container.appendChild(noteElement);
        });
    }
});